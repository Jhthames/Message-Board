const express = require("express");
const app = express();
const mongoose = require('mongoose');
const server = app.listen(8000, () => console.log("listening on port 8000"));
const flash = require('express-flash');
app.use(flash());
const session = require('express-session');

app.use(session({
    secret: 'mysecret',
    resave: false,
    saveUninitialized: true,
    cookie: { maxAge: 60000 }
}))

mongoose.connect('mongodb://localhost/board_DB', {useNewUrlParser: true});

const CommentSchema = new mongoose.Schema({
    name: {
        type: String,
        required: [true, "Must have name"],
        minlength: 3
    },
    content: {
        type: String,
        required: [true, "Comments must have content"],
        maxlength: 50
    },
}, {timestamps: true});
const MessageSchema = new mongoose.Schema({
    name: {
        type: String,
        required: [true, "Must have name"],
        minlength: 3
    },
    content: {
        type: String,
        required: [true, "Posts must have content"],
        maxlength: 50
    },
    comments: [CommentSchema]
}, {timestamps: true});

const Message = mongoose.model('Message', MessageSchema);
const Comment = mongoose.model('Comment', CommentSchema);

app.set('view engine', 'ejs');
app.use(express.static(__dirname + "/static"));
app.set('views', __dirname + '/views');
app.use(express.urlencoded({extended: true}));

app.get('/', (req, res) => {
    
    Message.find()
    //.populate({path: 'comments', model: Comment})
        .then(data => res.render("index", {messages: data}))
        .catch(err => res.json(err));
})
app.post('/message', (req, res) => {
    var message = new Message();
    message.name = req.body.name;
    message.content = req.body.content
    message.save()
    .then(() => res.redirect('/'))
    .catch(err => {
        console.log("We have an error!", err);
        // adjust the code below as needed to create a flash message with the tag and content you would like
        for (var key in err.errors) {
            req.flash('registration', err.errors[key].message);
        }
        res.redirect('/');
    });
})
app.post('/comment', (req, res) => {
    var comment = new Comment();
    comment.name = req.body.name;
    comment.content = req.body.content
    comment.save()
    console.log(req.body.message_id)
    updated_message = Message.updateOne({_id: req.body.message_id}, {$set: {comments: comment}})
    .then(() => res.redirect('/'))
    .catch(err => {
        console.log("We have an error!", err);
        // adjust the code below as needed to create a flash message with the tag and content you would like
        for (var key in err.errors) {
            req.flash('registration', err.errors[key].message);
        }
        //console.log(updated_message)
        res.redirect('/');
    });
})

